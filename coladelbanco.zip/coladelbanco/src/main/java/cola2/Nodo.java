package cola2;

public class Nodo {

    Cliente cliente; 
    Nodo seguirNodo;
    

    public Nodo(Cliente cliente) {
        this.cliente = cliente;
        this.seguirNodo = null;
    } 

    
    
}




